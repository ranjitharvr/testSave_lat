package LiveServices;
import testSave.*;
import java.awt.AWTException;
import java.awt.Menu;
import java.awt.MenuItem;
import java.awt.PopupMenu;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class NotifPanel {
	public void getPanel() {
        //Check the SystemTray support
        if (!SystemTray.isSupported()) {
            System.out.println("SystemTray is not supported");
            return;
        }
        String icoPath = "bulb.png";
        final PopupMenu popup = new PopupMenu();
        final TrayIcon trayIcon =
        		 new TrayIcon(new ImageIcon(icoPath, "omt").getImage(), "Java App");
        final SystemTray tray = SystemTray.getSystemTray();
         
       

        // Create a popup menu components
        MenuItem aboutItem = new MenuItem("About");
       
        Menu displayMenu = new Menu("Display");
        MenuItem errorItem = new MenuItem("Error");
        MenuItem infoItem = new MenuItem("Info");
        MenuItem exitItem = new MenuItem("Exit");
        MenuItem weeklyStat = new MenuItem("Weekly Statistics");
        MenuItem dailyStat = new MenuItem("Daily Statistics");
        
         
        //Add components to popup menu
        popup.add(weeklyStat);
        popup.addSeparator();
        popup.add(dailyStat);     
        popup.addSeparator();
        popup.add(aboutItem);
        popup.addSeparator();
        popup.add(displayMenu);
        displayMenu.add(errorItem);
        popup.addSeparator();
        displayMenu.add(infoItem);
        popup.add(exitItem);
        
        trayIcon.setPopupMenu(popup);
         
        try {
            tray.add(trayIcon);
        } catch (AWTException e) {
            System.out.println("TrayIcon could not be added.");
            return;
        }
         
        trayIcon.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,
                        "This dialog box is run from System Tray");
            }
        });
         
        aboutItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,
                        "Watch directory service is running in the background");
            }
        });
         
        ActionListener listener = new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                MenuItem item = (MenuItem)e.getSource();
                //TrayIcon.MessageType type = null;
                //System.out.println(item.getLabel());
                if ("Error".equals(item.getLabel())) {
                    //type = TrayIcon.MessageType.ERROR;
                    trayIcon.displayMessage("Sun TrayIcon Demo",
                            "This is an error message", TrayIcon.MessageType.ERROR);
                     
                } else if ("Info".equals(item.getLabel())) {
                    //type = TrayIcon.MessageType.INFO;
                    trayIcon.displayMessage("Sun TrayIcon Demo",
                            "This is an info message", TrayIcon.MessageType.INFO);
                     
                } else if ("Weekly Statistics".equals(item.getLabel())) {
                    Statistics st = new Statistics("Active Hours Statistics", "Active hours during last 7 days");
                    st.getChart();
                     
                } else if ("Daily Statistics".equals(item.getLabel())) {
                    DailyStat dt = new DailyStat("Active Hours Statistics", "Active hours today");
                    dt.getChart();
                     
                } 
            }
        };
         
        errorItem.addActionListener(listener);
        infoItem.addActionListener(listener);
        weeklyStat.addActionListener(listener); 
        dailyStat.addActionListener(listener); 
        exitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                tray.remove(trayIcon);
                System.exit(0);
            }
        });
        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {
               
                int i = 0;
                while (true) {
                    i++;
                    try {
                        Thread.sleep(10000);
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    trayIcon.displayMessage("Watch Directory Process Message",
                            "This is message number " + i,
                            TrayIcon.MessageType.INFO);
                }

            }
        });

        thread.start();
      
    }
     

}
