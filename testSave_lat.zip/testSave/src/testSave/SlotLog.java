package testSave;
import java.io.IOException;
import java.sql.*;

import javax.swing.JOptionPane;

public class SlotLog
{
	
	public static void InsertValues( String args[] ) throws IOException 
	  {
		JOptionPane.showMessageDialog(null, "Comes initially");
		System.out.println("FIltered Values ARe: " +args[0]);
	    Connection c = null;
	    Statement stmt = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      c = DriverManager.getConnection("jdbc:sqlite:test.db");
	      c.setAutoCommit(false);
	      System.out.println("Opened database successfully");
	      String pid = args[0];
	      int mid = Integer.parseInt(args[2]);
	      int kid = Integer.parseInt(args[1]);
	      stmt = c.createStatement();
	      String sql = "INSERT INTO SLOTLOG (END_TIME,KEY_CLICKS,MOUSE_CLICKS)"
	      			+ "VALUES	('"+pid+"',"+kid+","+mid+");";
	      System.out.println(sql);
	      stmt.executeUpdate(sql);
	      //prep1.setString(1, ts);//add values into cell
	      //prep1.setString(2, answer3);
	      //prep1.addBatch();//add the columns that have been entered

	      
	      //c.setAutoCommit(false);
	      //prep1.executeBatch();
	      //prep2.executeBatch();
	      //c.setAutoCommit(true);

	      

	      stmt.close();
	      c.commit();
	      c.close();
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      JOptionPane.showMessageDialog(null, "Error occurred");
	      System.exit(0);
	    }
	    System.out.println("Records created successfully");
	    JOptionPane.showMessageDialog(null, "Slots cretaed successfully");
	  }
}