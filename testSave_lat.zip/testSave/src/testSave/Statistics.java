package testSave;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel; 
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset; 
import org.jfree.data.category.DefaultCategoryDataset; 
import org.jfree.ui.ApplicationFrame; 
import org.jfree.ui.RefineryUtilities; 

@SuppressWarnings("serial")
public class Statistics extends ApplicationFrame
{
   public Statistics( String applicationTitle , String chartTitle )
   {
	   
	   
	   
      super( applicationTitle );    
      
      JFreeChart barChart = ChartFactory.createBarChart(
         chartTitle,           
         "Day",            
         "Total Active Hours",            
         createDataset(),          
         PlotOrientation.VERTICAL,           
         true, true, false);
         
      ChartPanel chartPanel = new ChartPanel( barChart );        
      chartPanel.setPreferredSize(new java.awt.Dimension( 560 , 367 ) );        
      setContentPane( chartPanel ); 
   }
   private CategoryDataset createDataset( )
   {
	          
      final DefaultCategoryDataset dataset = 
      new DefaultCategoryDataset( );  
      
      Connection c = null;
	    Statement stmt = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      c = DriverManager.getConnection("jdbc:sqlite:test.db");
	      c.setAutoCommit(false);
	      //System.out.println("Opened database successfully");

	      stmt = c.createStatement();
	      ResultSet rs = stmt.executeQuery( "SELECT *,strftime('%Y-%m-%d', START_TIME) as Day ,SUM((strftime('%s',END_TIME) - strftime('%s',START_TIME)) / 3600) as totalHours FROM ACTIONLOG WHERE START_TIME  BETWEEN datetime('now', '-7 days') AND datetime('now', 'localtime')  GROUP BY strftime('%Y-%m-%d', START_TIME);" );
	      while ( rs.next() ) {
	         //int id = rs.getInt("ID");
	         int hour_diff = rs.getInt("totalHours");
	         String day = rs.getString("Day");
	         dataset.addValue( hour_diff , day , day ); 
	         
	      }
	      rs.close();
	      stmt.close();
	      c.close();
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	     
	    }
            return dataset; 
   }
   public void getChart(  )
   {
	  Statistics chart = new Statistics("Active Hours Statistics", "Active hours during last 7 days");
      chart.pack( );        
      RefineryUtilities.centerFrameOnScreen( chart );        
      chart.setVisible( true ); 
   }
}