package testSave;

import java.awt.MouseInfo;
import java.awt.Point;

public class MouseState extends EnumerateWindows {
	
	public int mouseState()
	{
	//Getting the mouse position on the whole desktop
		
	    Point location = MouseInfo.getPointerInfo().getLocation() ;
	    System.out.println(location);
	    int x = (int) location.getX();
	    int y = (int) location.getY();
	    
	    //getting the difference in co-ordinates.
	    int diffx, diffy;
	    diffx = EnumerateWindows.x1 - EnumerateWindows.x2;
	    diffy = EnumerateWindows.y1 - EnumerateWindows.y2;
	    EnumerateWindows.x1 = EnumerateWindows.x2;
	    EnumerateWindows.x2 = x;
	    EnumerateWindows.y1 = EnumerateWindows.y2;
	    EnumerateWindows.y2 = y;
	    System.out.println(diffx + "              " + diffy);
	    
	    if (diffx==0 && diffy==0)
	    {
	    	EnumerateWindows.mouseCount++;
	    	if(EnumerateWindows.mouseCount>=100000)
	    	{
	    		System.out.println("Inactive Mouse");
	    	}
	    }
	    else {
	    	EnumerateWindows.mouseCount=0;
	    	EnumerateWindows.mousePress++;
	    }
		
		return EnumerateWindows.mousePress;
	}
}
