package testSave;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class getInstalledApplications {

  private static final String REGQUERY_UTIL = "reg query ";
  private static final String REGSTR_TOKEN = "REG_SZ";
  static String s = REGQUERY_UTIL + "HKEY_LOCAL_MACHINE\\Software"
                    + "\\Wow6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall";
//Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall
  public static int maxCount = 200;
  public static List<String> list = new ArrayList<String>();
  

public static String getCurrentUserPersonalFolderPath() {
    try {
      Process process = Runtime.getRuntime().exec(s);
      StreamReader reader = new StreamReader(process.getInputStream());

      reader.start();
      process.waitFor();
      reader.join();

      String result = reader.getResult();
      int p = result.indexOf(REGSTR_TOKEN);

      /*if (p == -1)
         return null;*/

      return result.substring(p + REGSTR_TOKEN.length()).trim();
    }
    catch (IOException | InterruptedException e) {
    	System.out.println(e);
      return null;
    }
  }



  static class StreamReader extends Thread {
    private final InputStream is;
    private final StringWriter sw;

    StreamReader(InputStream is) {
      this.is = is;
      sw = new StringWriter();
    }

    @Override
    public void run() {
      try {
        int c;
        while ((c = is.read()) != -1)
          sw.write(c);
        }
        catch (IOException e) { e.printStackTrace(); }
      }

    String getResult() {
      return sw.toString();
    }
  }

  /*public static void main(String s[]) {

      getDisplayNameDword( getCurrentUserPersonalFolderPath()  );
  }
*/
  public void getDisplayNameDword(String str){

      Set<String> set = new HashSet<>();
     // Set<String> latSet = new HashSet<>();
      String [] array = new String[500];
      String [] appArray = new String[maxCount];

      array = str.split("\n");
      System.out.println(array);
      int counter=0;
      
      for(String i : array){
    	  String temp = new String();
    	  appArray[counter] = getName(i.trim());
    	  temp = getName(i.trim());
    	  if(temp==null || temp.isEmpty() || temp.contains("Update")|| temp.contains("update"))
    		  continue;
          set.add( getName(i.trim()) ); 
          counter++;
      		}
      set.add("Eclipse");
      set.add("Notepad++");
      System.out.println(set);
      list = new ArrayList<String>(set);
      Collections.sort(list);
      System.out.println("List is :" +list.toString());
      
  }

  private static String getName(String s){
  Process process = null;
  try {
            // Run reg query, then read output with StreamReader (internal class)
             process = Runtime.getRuntime().exec("reg query " + 
                    '"'+ s + "\" /v " + "DisplayName");

            StreamReader reader = new StreamReader(process.getInputStream());
            reader.start();
            process.waitFor();
            reader.join();


            // Parse out the value
            String[] parsed = reader.getResult().split(REGSTR_TOKEN);
            if (parsed.length > 1) {
            return  (parsed[parsed.length-1]).trim();
            }

       } catch (IOException | InterruptedException e) {
           e.printStackTrace();
       }
  return null;
  }
}