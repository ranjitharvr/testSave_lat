package testSave;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AppFocusLogic {

	public void gotFocus(String oldName, String currentName) throws IOException
	{
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String formattedDate = sdf.format(date);
		System.out.println("Time and date is:" +formattedDate);
		System.out.println("Old and current names are" +oldName+ "        "+currentName);
		if(oldName.length()==0)
		{
			System.out.println("User got focus on the application: " +currentName +" at "+formattedDate);
			EnumerateWindows.nameOld = currentName;
			EnumerateWindows.startTime = formattedDate;
		}
		else if (!(oldName.equals(currentName)))
			try {
				{
					String[] callArray = new String[5];
					callArray[0] = EnumerateWindows.startTime;
					callArray[1] = formattedDate;
					callArray[2] = oldName;
					callArray[3] = String.valueOf(EnumerateWindows.keyPress);
					callArray[4] = String.valueOf(EnumerateWindows.mousePress);
					
					System.out.println("User lost the focus from: " + oldName + " to : "+currentName  +" at "+formattedDate);
					EnumerateWindows.nameOld = currentName;
					EnumerateWindows.endTime = formattedDate;
					SQLiteJDBC.InsertValues(callArray);
					EnumerateWindows.keyPress = 0;
					EnumerateWindows.mousePress = 0;
					EnumerateWindows.startTime = formattedDate;
					EnumerateWindows.latexFlag = false;
				} 
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		else
		{
			System.out.println("User is working with the same application named: " +currentName);
		}
	}
}
