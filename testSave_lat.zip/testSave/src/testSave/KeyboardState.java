package testSave;

import com.sun.jna.platform.KeyboardUtils;

public class KeyboardState extends EnumerateWindows{
	 /* For globally keyboard access. To check whether some key is being pressed or not*/
	
    public int CheckState()
    {
    	 System.out.println(EnumerateWindows.KeyboardState);
    	 int count = 0;
    	 boolean a = false;
    	 	for (count=0;count<256;count++)
    	 		{
    	 			a= KeyboardUtils.isPressed(count);
    	 				if(a)
    	 				{
    	 					EnumerateWindows.keyPress++;
    	 					EnumerateWindows.KeyboardState=0;
    	 					break;
    	 				}
    	 				else
    	 				{
    	 					EnumerateWindows.KeyboardState++;
    	 					if(EnumerateWindows.KeyboardState>=100000)
    	 					{
    	 						System.out.println("Inactive Keyboard");
    	 					}
    	 				}
    	 		}
    	 	if(KeyboardUtils.isPressed(0))
    	 	{
    	 		if(KeyboardUtils.isPressed(83) || KeyboardUtils.isPressed(115))
    	 		{
    	 			System.out.println("File Saved");
    	 		}
    	 	}
    	 	System.out.println("a is :" +a);
    	 	return EnumerateWindows.keyPress;
    }
    
}
