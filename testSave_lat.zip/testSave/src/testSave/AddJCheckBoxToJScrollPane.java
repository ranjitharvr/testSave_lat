package testSave;

import java.awt.BorderLayout;
import java.awt.CheckboxGroup;
import java.awt.Component;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import LiveServices.NotifPanel;

public class AddJCheckBoxToJScrollPane {

    private JFrame frame = new JFrame();
    private JPanel jPanel1;
    private JScrollPane jScrollPane1;
    List<String> process= getInstalledApplications.list;
    static ArrayList<String> finalSelection = new ArrayList<String>();
    public static int counter = 0;
    static JButton buttonSubmit = new JButton("Submit");
	static JButton buttonCancel = new JButton("Cancel");
	public static List<String> checkboxes = new ArrayList<String>();
    public AddJCheckBoxToJScrollPane() {
        jPanel1 = new JPanel();
        jPanel1.setLayout(new GridLayout(0, 2, 10, 10));
        jScrollPane1 = new JScrollPane(jPanel1);
        String temp[] = new String[process.size()];
    	String ask = new String();
    	String[] latexArray ={"Archimedes","Bakoma TeX Word","AUCTeX","WhizzyTeX","gedit","GeanyLaTeX",
      		  "gummi","Inlage","jEdit","JOVE","Kile","KTIkZ","Latexian","Latexila","LEd","LyX","Notepad++",
      		  "Overleaf","Latex Studio","Papeeria","QuatraTex","RTextDoc","DMelt","Scribes","Scribo",
      		 "LateXTools","LaTeXing Plugin","ShareLaTeX","TechWriter","TeXlipse","Texmaker","TeXnicCenter",
      		 "TeXnicle","TexPad","Texpen","TeXStudio","TexMate","TeXWorks","Verbosus"};
    	List<String> latexList = new ArrayList<String>();
    	latexList.addAll(Arrays.asList(latexArray));
    	System.out.println(latexList);
    	for (String s : process)
    	{
    		ask += s +","; 
    	}
    	jScrollPane1 = new JScrollPane(jPanel1);
    	System.out.println(ask);
    	temp=ask.split(",");
    	for(int i=0; i<process.size();i++)
    	{
    		
    		//cbs[i] = JCheckBox(temp[i],false);
    		JCheckBox cb = new JCheckBox(temp[i]);
            counter++;
            /*cbg(cb);*/
            jPanel1.add(cb);
            jPanel1.revalidate();
            jPanel1.repaint();
    	}
    	buttonSubmit.setActionCommand("Submit");
    	buttonCancel.setActionCommand("Cancel");
        frame.add(jScrollPane1);
        frame.add(buttonSubmit,BorderLayout.SOUTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(850, 600);
        //frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
        
        /* Check Box Logic*/
        final class ButtonClickListener implements ActionListener{
	        @SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
	           String command = e.getActionCommand();  
	           if( command.equals( "Submit"))  {
	        	   
	        	   System.out.println(jScrollPane1.getComponents());
	        	  
	        	   for( Component comp : jPanel1.getComponents() ) {
	        	      if( comp instanceof JCheckBox) 
	        	    	  if(((JCheckBox) comp).isSelected())
	        	    	  checkboxes.add(((JCheckBox) comp).getLabel());
	        	   }
	        	   if (!Collections.disjoint(checkboxes, latexList))
	        	   {
	        	     System.out.println("There is something in common");
	        	     frame.setVisible(false);
	        	     DirectoryChooser dc = new DirectoryChooser();
	        	     try {
						dc.FileChooser(checkboxes);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
	        	        
	        	   }
	        	   else
	        	   {
	        		   JOptionPane.showMessageDialog(null, "Please select at least one LaTeX Editor");
	        	   }
	        	   System.out.println("XXXXXXXXX:" +checkboxes);
	        	   
	           }
	           else  {
	          	 System.exit(0);
	           }  	
	        }		
	     }
	    
        /*CheckBox Logic Ends Here*/   
	    
        buttonSubmit.addActionListener(new ButtonClickListener()); 
   	 	buttonCancel.addActionListener(new ButtonClickListener()); 
   	 	
     
        
    }

    public static void main(String args[]) {
    	getInstalledApplications gia = new getInstalledApplications();
        gia.getDisplayNameDword(getInstalledApplications.getCurrentUserPersonalFolderPath());
        
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
        } catch (InstantiationException ex) {
        } catch (IllegalAccessException ex) {
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
        }
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new AddJCheckBoxToJScrollPane();
            }
        });
    }
}