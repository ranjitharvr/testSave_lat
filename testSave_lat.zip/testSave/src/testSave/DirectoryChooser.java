package testSave;

import javax.swing.*;

import java.awt.Dimension;
import java.awt.event.*;
import java.io.IOException;
import java.util.List;


public class DirectoryChooser extends JFileChooser implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	JButton go;

	   JFileChooser chooser;
	   String choosertitle;
	   JFrame frame;
	   List<String> checkBoxes;
	   EnumerateWindows ecw = new EnumerateWindows();
	  
	public void FileChooser(List<String> arr) throws IOException
	{
		//panel = new DirectoryChooser(); 
		frame = new JFrame("");
		chooser = new JFileChooser(); 
	    chooser.setCurrentDirectory(new java.io.File("."));
	    chooser.setDialogTitle("Plase select a working directory!");
	    //chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	    //
	    // disable the "All files" option.
	    //
	   // chooser.setAcceptAllFileFilterUsed(false);
	    
	    frame.addWindowListener(
	      new WindowAdapter() {
	        public void windowClosing(WindowEvent e) {
	          System.exit(0);
	          }
	        }
	      );
	    	if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) { 
		      System.out.println("getCurrentDirectory(): " 
		         +  chooser.getCurrentDirectory());
		      System.out.println("getSelectedFile() : " 
		         +  chooser.getSelectedFile());
		      this.setVisible(false);
		      try {
		    	  //System.out.println("Checsndmdw :"+checkBoxes);
				ecw.FetchData(checkBoxes,chooser.getCurrentDirectory());
		      } catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
		      }
		    }
		    else {
		      System.out.println("No Selection ");
		      JOptionPane.showMessageDialog(null, "Please select proper path");
		      frame.setVisible(true);
		      }
		 
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//panel.setVisible(false);
		//    
	    
	}
	public Dimension getPreferredSize(){
	    return new Dimension(600, 600);
	    }

}