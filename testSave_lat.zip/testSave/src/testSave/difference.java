package testSave;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedList;

import testSave.TextDiffMatchPatch;
import testSave.TextDiffMatchPatch.Diff;

public class difference {
	public static void main(String args[]) throws IOException
	{
		StringBuilder builder = new StringBuilder();
    	

        File dir = new File("C:/Users/Archit/Desktop/test");    //Directory path
        File[] files = dir.listFiles();
        Arrays.sort(files, new Comparator<File>()           
        
        {            	
            public int compare(File f1, File f2)           // Sorting the files
            {
                return Long.valueOf(f2.lastModified()).compareTo
                        (
                        f1.lastModified());
                                   
            }
        });
        
        	for(int i=0, length=Math.min(files.length, 2); i<length; i++) {
        	}                                                                     //getting top 2 files from the folder
        		builder.append(files[0]).append("\n");            		         		
        		builder.append(files[1]).append("\n"); 
		
				// Diff starts
        		
        	File f1 = files[0];
       	    File f2 = files[1];

	     FileReader fR1 = new FileReader(f1);
	     FileReader fR2 = new FileReader(f2);

	     BufferedReader reader1 = new BufferedReader(fR1);
	     BufferedReader reader2 = new BufferedReader(fR2);
	     
	     String line1 = null;
	     String line2 = null;
	     
	     while (((line1 = reader1.readLine()) != null)
	                && ((line2 = reader2.readLine()) != null)) {
	            if (!line1.equalsIgnoreCase(line2));
	                //flag = 0;
	            TextDiffMatchPatch dmp = new TextDiffMatchPatch();
	    		
	    		dmp.getDiffTimeout();
	    		
	    		LinkedList<Diff> deltas = (LinkedList<Diff>) dmp.diffMain(line1, line2);
	    		dmp.diffCleanupSemantic(deltas);
	    		
	    		System.out.println(deltas);
	        }
		

		reader1.close();
	    reader2.close();
	}
	
}