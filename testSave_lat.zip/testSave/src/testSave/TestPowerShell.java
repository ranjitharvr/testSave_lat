package testSave;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class TestPowerShell {

    public static void main(String[] args) throws IOException 
    {
        Runtime runtime = Runtime.getRuntime();
        Process proc = runtime.exec("powershell C:\\testscript.ps1");
        InputStream is = proc.getInputStream();
        InputStreamReader isr = new InputStreamReader(is);
        BufferedReader reader = new BufferedReader(isr);
        String line;
        while ((line = reader.readLine()) != null)
        {
            System.out.println(line);
        }
        reader.close();
        proc.getOutputStream().close();
    }

}