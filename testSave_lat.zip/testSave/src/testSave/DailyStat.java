package testSave;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel; 
import org.jfree.chart.JFreeChart; 
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.CategoryDataset; 
import org.jfree.data.category.DefaultCategoryDataset; 
import org.jfree.ui.ApplicationFrame; 
import org.jfree.ui.RefineryUtilities; 

@SuppressWarnings("serial")
public class DailyStat extends ApplicationFrame
{
   public DailyStat( String applicationTitle , String chartTitle )
   {
	   
      super( applicationTitle );    
      
      JFreeChart barChart = ChartFactory.createBarChart(
         chartTitle,           
         "Time",            
         "Total Hours",            
         createDataset(),          
         PlotOrientation.VERTICAL,           
         true, true, false);
         
      ChartPanel chartPanel = new ChartPanel( barChart );        
      chartPanel.setPreferredSize(new java.awt.Dimension( 560 , 367 ) );        
      setContentPane( chartPanel ); 
   }
   private CategoryDataset createDataset( )
   {
	          
      final DefaultCategoryDataset dataset = 
      new DefaultCategoryDataset( );  
      
      Connection c = null;
	    Statement stmt = null;
	    try {
	      Class.forName("org.sqlite.JDBC");
	      c = DriverManager.getConnection("jdbc:sqlite:test.db");
	      c.setAutoCommit(false);
	      //System.out.println("Opened database successfully");

	      stmt = c.createStatement();
	      ResultSet rs = stmt.executeQuery( "SELECT *,strftime('%H:%M',START_TIME) as startingTime,strftime('%H:%M',END_TIME) as endingTime,(strftime('%s',END_TIME) - strftime('%s',START_TIME) ) /3600  as totalHours  FROM ACTIONLOG WHERE strftime('%Y-%m-%d',START_TIME) = strftime('%Y-%m-%d','now') ORDER BY ID" );
	      
	      while ( rs.next() ) {
	    	  //System.out.println(rs.first());
	         //int id = rs.getInt("ID");
	         String  start_time = rs.getString("startingTime");
	         String  end_time = rs.getString("endingTime");
	         String application_name = rs.getString("APPLICATION_NAME");
	         int totalHour  = rs.getInt("totalHours");
	         //System.out.println(totalHour);
	         //int totalMin  = rs.getInt("TotalMin");
	         //System.out.println(totalMin);
	         //String day = rs.getString("Day");
	         //dataset.addValue( hour_diff , day , day ); 
	        //dataset.addValue( totalHour , start_time+" - "+end_time , application_name ); 
	         dataset.addValue( totalHour ,application_name,start_time+" - "+end_time   );
	         
	      }
	      rs.close();
	      stmt.close();
	      c.close();
	    } catch ( Exception e ) {
	      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
	      //System.exit(0);
	    }
            return dataset; 
   }
   public void getChart( )
   {
	   DailyStat chart = new DailyStat("Active Hours Statistics", "Active hours today");
      chart.pack( );        
      RefineryUtilities.centerFrameOnScreen( chart );        
      chart.setVisible( true ); 
   }
}