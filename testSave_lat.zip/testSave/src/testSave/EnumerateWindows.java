package testSave;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.swing.JOptionPane;

import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.Kernel32;
import com.sun.jna.platform.win32.User32;
import com.sun.jna.platform.win32.WinDef;
import com.sun.jna.platform.win32.WinDef.HWND;
import com.sun.jna.platform.win32.WinNT;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.win32.StdCallLibrary;

import LiveServices.NotifPanel;


public class EnumerateWindows implements Runnable {
	
	//*********** Global Variables Declaration **********//
	public static int KeyboardState = 0;
	public static int mouseCount = 0;
	public static int x1 = 0;
	public static int x2 = 0;
	public static int y1 = 0;
	public static int y2 = 0;
	public static int timeCounter = 0;
	public static int keyPress = 0;
	public static int mousePress = 0;
	public static boolean latexFlag = false;
	public static String nameOld = new String();
	public static String CurrentApp = new String();
	public static String startTime = new String();
	public static String endTime = new String();
	public static List<String> selectedApps = new ArrayList<String>();
	public static String fileLocation = new String();
	//**************************************************//
	private static final int MAX_TITLE_LENGTH = 1024;
	//Get-WmiObject -Class Win32_Product | Select-Object -Property Name
	public void run() {
		try{
			System.out.println(System.getenv("ProgramFiles(X86)"));
			Thread.sleep(1000);
			String[] latexArray ={"Archimedes","Bakoma TeX Word","AUCTeX","WhizzyTeX","gedit","GeanyLaTeX",
		      		  "gummi","Inlage","jEdit","JOVE","Kile","KTIkZ","Latexian","Latexila","LEd","LyX","Notepad++",
		      		  "Overleaf","Latex Studio","Papeeria","QuatraTex","RTextDoc","DMelt","Scribes","Scribo",
		      		 "LateXTools","LaTeXing Plugin","ShareLaTeX","TechWriter","TeXlipse","texmaker","TeXnicCenter",
		      		 "TeXnicle","TexPad","Texpen","TeXStudio","TexMate","TeXWorks","Verbosus"};
            // Getting the page or project name which is open in the foreground application.
            char[] buffer = new char[MAX_TITLE_LENGTH * 2];
            HWND hwnd = User32.INSTANCE.GetForegroundWindow();
            User32.INSTANCE.GetWindowText(hwnd, buffer, MAX_TITLE_LENGTH);
            System.out.println("Active window title: " + Native.toString(buffer));
           
            /*Temp code*/
            final int PROCESS_VM_READ=0x0010;
            final int PROCESS_QUERY_INFORMATION=0x0400;
            final User32 user32 = User32.INSTANCE;
            final Kernel32 kernel32=Kernel32.INSTANCE;
            final Psapi psapi = Psapi.INSTANCE;
            
            /* Get the document information of an application */
            WinDef.HWND windowHandle=user32.GetForegroundWindow();
            IntByReference pid= new IntByReference();
            user32.GetWindowThreadProcessId(windowHandle, pid);
            WinNT.HANDLE processHandle=kernel32.OpenProcess(PROCESS_VM_READ | PROCESS_QUERY_INFORMATION, true, pid.getValue());
            
            /* To get the application name which is in foreground*/
            
            String[] apps = new String[selectedApps.size()];
            apps = selectedApps.toArray(apps);
            for (int j = 0; j<latexArray.length; j++)
            {
            	latexArray[j] = latexArray[j].toLowerCase();
            }
            for(int i=0; i < apps.length; i++) {
            	  apps[i] =apps[i].toLowerCase();
            	}
            System.out.println(apps);
            //Arrays.asList(yourArray).contains(yourValue)

            char[] filename = new char[64];
            psapi.GetModuleBaseNameW(processHandle.getPointer(), Pointer.NULL, filename, filename.length);
            String bufferString = new String(filename).trim().replaceAll(" ", "");
            String name=new String(bufferString);
            name=name.replace(".exe", "");
            System.out.println("Name is :::: "+name);
            
            /* Calls the method about active state and inactive state of uses.*/
            KeyboardState ks = new KeyboardState();
            AppFocusLogic afl = new AppFocusLogic();
            MouseState ms = new MouseState();
            if(Arrays.asList(latexArray).contains(name))
            {
            	latexFlag = true;
            }
            System.out.println(selectedApps);
            
            {
            	System.out.println("Name is " +name+ "Apps "+selectedApps);
                if(Arrays.asList(apps).contains(name) && latexFlag)
                {
                	System.out.println("Tin tin tidin" + nameOld);
                	CurrentApp = name;
                	timeCounter++;
                	// System Time at this moment
                    Date date = new Date();
            		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            		String formattedDate = sdf.format(date);
            		System.out.println("Time and date is:" +formattedDate);
            		//startTime = formattedDate;
            		int keyClicks =0, keyClicksInst =0;
            		int mouseClicks = 0, mouseClicksInst =0; 
            		if(nameOld != name)
            		{
            			keyClicks+=keyClicksInst;
            			mouseClicks+=mouseClicksInst;
    	        		keyClicksInst = ks.CheckState();
    	        		mouseClicks = ms.mouseState();
    	        		
            		}
            		if (timeCounter ==10)
            		{
                		String formattedDateEnd = sdf.format(date);
                		String[] arguments = new String[3];
                		arguments[0] = formattedDateEnd;
                		arguments[1] = String.valueOf(keyClicksInst);
                		arguments[2] = String.valueOf(mouseClicksInst);
            			SlotLog.InsertValues(arguments);
            			System.out.println("keyClicks are :" +keyClicks);
            			System.out.println("mouseClicks are :" +mouseClicks);
            			timeCounter = 0;
            			
            			keyClicksInst = 0;
            			mouseClicksInst = 0;
            		}
            		afl.gotFocus(nameOld, name);
            		
                }
                else
                {
                	mouseCount=0;
                	KeyboardState=0;
                	timeCounter = 0;
                	if(nameOld.length()>0)
                	{
                		Date date = new Date();
                		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                		String formattedDate = sdf.format(date);
                		System.out.println("Time and date is:" +formattedDate);
                		
                		System.out.println("Window lost focus from the Application: " +nameOld);
                		String[] callArray = new String[5];
    					callArray[0] = EnumerateWindows.startTime;
    					callArray[1] = formattedDate;
    					callArray[2] = nameOld;
    					callArray[3] = String.valueOf(EnumerateWindows.keyPress);
    					callArray[4] = String.valueOf(EnumerateWindows.mousePress);
    					JOptionPane.showMessageDialog(null, "Please select proper path");
    					SQLiteJDBC.InsertValues(callArray);
                		nameOld = "";
                		
                	}
                }
        
            }        
            /*Temp code*/
        } catch (Exception e) {
        	System.out.println(e);
        }
	}
	
	public interface Psapi extends StdCallLibrary {
	    Psapi INSTANCE = (Psapi) Native.loadLibrary("Psapi", Psapi.class);

	    WinDef.DWORD GetModuleBaseNameW(Pointer hProcess, Pointer hModule, char[] lpBaseName, int nSize);
	}
	
    public void FetchData(List<String> cbs,File file ) throws Exception {
    	
    	selectedApps = AddJCheckBoxToJScrollPane.checkboxes;
    	System.out.println("Slected app are:" +selectedApps);
    	fileLocation = String.valueOf(file);
        for(;;)
        {
        Thread t = new Thread(new EnumerateWindows());
        t.setDaemon(true);
        t.run();
        /*NotifPanel np = new NotifPanel();
	    np.getPanel();
		*/ 
        }
        //Thread.sleep(1000);
        
        
    }
   
}