 package testSave;
import java.io.IOException;
import java.sql.*;

import javax.swing.JOptionPane;

public class SQLiteJDBC
{ 
  
 // @SuppressWarnings("null")
public static void InsertValues( String args[] ) throws IOException, SQLException 
  { 
	//JOptionPane.showMessageDialog(null, "Comes Initially here too");
	System.out.println("FIltered Values ARe: " +args[0]);
    Connection c = null;
    Statement stmt = null;
    Statement crstmt = null;
    try {
      Class.forName("org.sqlite.JDBC");
    
      c = DriverManager.getConnection("jdbc:sqlite:test.db");
      c.setAutoCommit(false);
      System.out.println("Opened database successfully");
      String pid = args[0];
      String tid = args[1];
      String rid = args[2];
      int mid = Integer.parseInt(args[4]);
      int kid = Integer.parseInt(args[3]);
      stmt = c.createStatement();
      String sql = "INSERT INTO ACTIONLOG (ID,START_TIME,END_TIME,APPLICATION_NAME,MOUSE_CLICKS,KEY_CLICKS)"
      			+ "	VALUES ((SELECT IFNULL(MAX(ID),0)+1 FROM ACTIONLOG), '"+pid+"','"+tid+"','"+rid+"',"+mid+","+kid+");";
      System.out.println(sql);
      stmt.execute(sql);
      //prep1.setString(1, ts);//add values into cell
      //prep1.setString(2, answer3);
      //prep1.addBatch();//add the columns that have been entered

      
      //c.setAutoCommit(false);
      //prep1.executeBatch();
      //prep2.executeBatch();
      //c.setAutoCommit(true);

      

      stmt.close();
      c.commit();
      c.close();
    } 
    catch ( SQLException e ) {
      System.err.println( e.getClass().getName() + ": " + e.getMessage() );
      //System.exit(0);
      {
    	  crstmt = c.createStatement();
	      String sql = "CREATE TABLE IF NOT EXISTS ACTIONLOG" + "(ID	INTEGER NOT NULL,"+	"START_TIME	TEXT NOT NULL,"
			  		+ "END_TIME	TEXT NOT NULL," + "APPLICATION_NAME	STRING NOT NULL," + "MOUSE_CLICKS	INT," + "KEY_CLICKS	INT,"
			  		+"PRIMARY KEY(START_TIME))";
	      crstmt.executeUpdate(sql);
	      crstmt.close();
	      InsertValues(args);
      }
//      JOptionPane.showMessageDialog(null, "Errorrr!!!!!!!!!!!!");
    }
    catch (Exception e)
    {
    	System.err.println( e.getClass().getName() + ": " + e.getMessage() );
    }
    System.out.println("Records created successfully");
//    JOptionPane.showMessageDialog(null, "Data Added");
  }
  
} 