package testSave;
import java.nio.file.*;
import static java.nio.file.StandardWatchEventKinds.*;
import static java.nio.file.LinkOption.*;
import java.nio.file.attribute.*;
import java.io.*;
import java.util.*;

import org.apache.commons.io.FilenameUtils;

/**
 * Example to watch a directory (or tree) for changes to files.
 */

public class WindowsUtils {

    private final WatchService watcher;
    private final Map<WatchKey,Path> keys;
    private final boolean recursive;
    private boolean trace = false;
    public static String origFile = new String();
    public static String copFile = new String();
    @SuppressWarnings("unchecked")
    static <T> WatchEvent<T> cast(WatchEvent<?> event) {
        return (WatchEvent<T>)event;
    }

    /**
     * Register the given directory with the WatchService
     */
    private void register(Path dir) throws IOException {
        WatchKey key = dir.register(watcher, ENTRY_CREATE, ENTRY_DELETE, ENTRY_MODIFY);
        if (trace) {
            Path prev = keys.get(key);
            if (prev == null) {
                System.out.format("register: %s\n", dir);
            } else {
                if (!dir.equals(prev)) {
                    System.out.format("update: %s -> %s\n", prev, dir);
                }
            }
        }
        keys.put(key, dir);
    }

    /**
     * Register the given directory, and all its sub-directories, with the
     * WatchService.
     */
    private void registerAll(final Path start) throws IOException {
        // register directory and sub-directories
        Files.walkFileTree(start, new SimpleFileVisitor<Path>() {
            @Override
            public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                throws IOException
            {
                register(dir);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    /**
     * Creates a WatchService and registers the given directory
     */
    WindowsUtils(Path dir, boolean recursive) throws IOException {
        this.watcher = FileSystems.getDefault().newWatchService();
        this.keys = new HashMap<WatchKey,Path>();
        this.recursive = recursive;

        if (recursive) {
            System.out.format("Scanning %s ...\n", dir);
            registerAll(dir);
            System.out.println("Done.");
        } else {
            register(dir);
        }

        // enable trace after initial registration
        this.trace = true;
    }

    /**
     * Process all events for keys queued to the watcher
     * @throws IOException 
     */
    void processEvents() throws IOException {
        for (;;) {

            // wait for key to be signalled
            WatchKey key;
            try {
                key = watcher.take();
            } catch (InterruptedException x) {
                return;
            }

            Path dir = keys.get(key);
            if (dir == null) {
                System.err.println("WatchKey not recognized!!");
                continue;
            }

            for (WatchEvent<?> event: key.pollEvents()) {
                @SuppressWarnings("rawtypes")
				WatchEvent.Kind kind = event.kind();

                // TBD - provide example of how OVERFLOW event is handled
                if (kind == OVERFLOW) {
                    continue;
                }

                // Context for directory entry event is the file name of entry
                WatchEvent<Path> ev = cast(event);
                Path name = ev.context();
                Path child = dir.resolve(name);
               // difference df = new difference();
                // print out event
                System.out.format("%s: %s\n", event.kind().name(), child);
                if(event.kind().name()=="ENTRY_MODIFY")
                {
                	System.out.println("File has been saved");
                		
                }
                else if (event.kind().name()=="ENTRY_CREATE")
                {
                	System.out.println("FIle created");
                	/*// Use relative path for Unix systems
                	String s = child.getFileName().toString();
                	s = s.substring(0,s.length()-4);
                	System.out.println(s);
                	if(s.length()>=5)
                	{
	                	String temp = s.substring(s.length()-5,s.length());
	                	if(temp.matches("_copy") )
	                	{
	                		System.out.println("Came inside");
	                		break;
	                	}
                	}
                	String ext = FilenameUtils.getExtension(child.toString());
                	System.out.println("extension is " +ext);
                	File f = new File(child.getParent().toString()+"\\"+s+"_copy."+ext);
                	f.getParentFile().mkdirs();
                	f.createNewFile();*/
                }
                else if(event.kind().name()=="ENTRY_DELETE")
                {
                	System.out.println("File deleted");
                	/*String s = child.getFileName().toString();
                	s = s.substring(0,s.length()-4);
                	System.out.println(s);
                	{
                		String ext = FilenameUtils.getExtension(child.toString());
                    	System.out.println("extension is " +ext);
                    	File f = new File(child.getParent().toString()+"\\"+s+"_copy."+ext);
                    	//if(f.canRead())
                    	{
	                    	f.getParentFile().mkdirs();
	                    	f.delete();
                    	}
                	}
                	*/
                }
                else if(event.kind().name() =="OVERFLOW"){
    	            System.out.println("OVERFLOW: more changes happened than we could retreive");
    	        }
                // if directory is created, and watching recursively, then
                // register it and its sub-directories
                if (recursive && (kind == ENTRY_CREATE)) 
                {
                	
                    try {
                        if (Files.isDirectory(child, NOFOLLOW_LINKS)) {
                            registerAll(child);
                        }
                    } catch (IOException x) {
                        // ignore to keep sample readbale
                    }
                }
            }

            // reset key and remove from set if directory no longer accessible
            boolean valid = key.reset();
            if (!valid) {
                keys.remove(key);

                // all directories are inaccessible
                if (keys.isEmpty()) {
                    break;
                }
            }
        }
    }
    public static void close(Closeable stream) {
        try {
            if (stream != null) {
                stream.close();
            }
        } catch(IOException e) {
            //...
        }
    }
    static void usage() {
        System.err.println("usage: java WatchDir [-r] dir");
        System.exit(-1);
    }

    public static void main(String[] args) throws IOException {
        // parse arguments
    	//String[] args = new String[1];
        if (args.length == 0 || args.length > 2)
            usage();
        boolean recursive = false;
        int dirArg = 0;
        if (args[0].equals("-r")) {
            if (args.length < 2)
                usage();
            recursive = true;
            dirArg++;
        }

        // register directory and process its events
        Path dir = Paths.get(args[dirArg]);
        new WindowsUtils(dir, recursive).processEvents();
    }
    
}