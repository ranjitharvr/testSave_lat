package testSave;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import org.apache.commons.io.FileUtils;

public class Timestamp {

	
	public static String ts;
	public static String doSomething() throws IOException {		
		
		
    	File source = new File("C:/Users/India/Desktop/Test/Sub/Test.docx");
    	
    
    	
    	SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH-mm-ss-ms");
		
		String ts=sdf.format(source.lastModified());
		System.out.print(ts);
		//String[] TimeStamp = source.lastModified().toString();
    	
    	String name = source.getName();
    	String ext = name.substring(name.lastIndexOf("."));
    	name = name.substring(0, name.lastIndexOf("."));
    	String outFileName = name + " " + ts + ext;
    	//System.out.println(" new file name is " + outFileName);

    	File destination = new File("C:/Users/India/Desktop/Test", outFileName);

		FileUtils.copyFile(source,destination);
		return ts;
		
		
		
	
		
		
	    }
/*public void setFoo(String foo){
	
	this.ts = ts;
	
}
public String getFoo()

{return this.ts; 
	}*/

	public static String getStringName()
	{System.out.println(ts);
	    return ts;
	}

public static void main (String [] args) throws IOException
{ doSomething();
getStringName();
  }
}
